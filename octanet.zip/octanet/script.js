document.querySelector('.hero button').addEventListener('click', () => {
    window.location.href = '#services';
});
